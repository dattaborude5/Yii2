<?php
namespace frontend\models;

use yii\base\Model;
use common\models\Person;

/**
 * Signup form
 */
class RegistrationForm extends Model
{
    public $name;
    public $email;
    public $mobile;
    public $dob;
    public $gender;
    public $playing_cricket;
    public $watching_TV;
    public $playing_computer_games;
    public $swiming;

    /**
     * @inheritdoc
     */
   
    public function rules()
    {
        return [
            ['name', 'required'],
            ['email', 'required'],
            ['email', 'email'],
            ['mobile', 'required'],
            ['mobile', 'string', 'min' => 10, 'max' => 12],
            ['mobile', 'integer'],
            ['dob', 'required'],
            ['gender', 'required'],            
            ['playing_cricket', 'required'],            
            ['watching_TV', 'required'],            
            ['playing_computer_games', 'required'],            
            ['swiming', 'required'],            
        ];
    }

    /**
     * Register user.
     *
     * @return User|null the saved model or null if saving fails
     */
    
    public function register()
    {
        if (!$this->validate()) {
            return null;
        }
        
        $person = new Person();
        $person->name = $this->name;
        $person->email = $this->email;
        $person->mobile = $this->mobile;
        $person->dob = $this->dob;
        $person->gender = $this->gender;
        $person->playing_cricket = $this->playing_cricket;
        $person->watching_TV = $this->watching_TV;
        $person->playing_computer_games = $this->playing_computer_games;
        $person->swiming = $this->swiming;
        
        return $person->save() ? $person : null;
    }
}
