<?php
namespace frontend\controllers;

use Yii;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use frontend\models\RegistrationForm;
use common\models\Person;

/**
 * Site controller
 */
class SiteController extends Controller
{
    
  
    /**
     * Displays homepage.
     *
     * @return mixed
     */
    public function actionIndex()
    {
        return $this->render('index');
    }

    /**
     * Displays test page.
     *
     * @return mixed
     */
    public function actionTest()
    {
        $model = new RegistrationForm();
        if ($model->load(Yii::$app->request->post())) {
            if ($user = $model->register()) {
                $persons = Person::find()->orderBy('id DESC')->all();
                return $this->render('test', [
                    'model' => $model,
                    'msg' => 'Registered successfully..!',
                    'persons' => $persons,
                ]);   
            }
        }
        $persons = Person::find()->orderBy('id DESC')->all();
        return $this->render('test', [
            'model' => $model,
            'msg' => '',
            'persons' => $persons,
        ]);
    }
}
