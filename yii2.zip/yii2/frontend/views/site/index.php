<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Home';
?>
<div class="site-test">
    <h1><?= Html::encode($this->title) ?></h1>
   <p>This is the Home page.</p>
</div>
