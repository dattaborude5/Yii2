<?php

/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use frontend\models\kartik\DatePicker;

$this->title = 'Test';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-test">
    <p><?= Html::encode($msg) ?></p>
    <h1><?= Html::encode($this->title) ?></h1>
    <p>Registration Form</p>
    <div class="row">
        <div class="col-lg-6">
            <?php $form = ActiveForm::begin(['id' => 'form-registration']); ?>

                <?= $form->field($model, 'name')->textInput(['autofocus' => true]) ?>

                <?= $form->field($model, 'email') ?>

                <?= $form->field($model, 'mobile') ?>

                <?= $form->field($model, 'dob')->widget(\yii\widgets\MaskedInput::className(), [
                    'clientOptions' => ['alias' =>  'dd-mm-yyyy']]); ?>
                
                <?php $list = ['Male' => 'Male', 'Female' => 'Female']; ?>
                <?= $form->field($model, 'gender')->radioList($list) ?>
             
                <div class="chk-box">
                    <?= $form->field($model,'playing_cricket')->checkBox(array('value'=>'Playing Cricket')) ?> 
                </div>

                <div class="chk-box">
                    <?= $form->field($model,'watching_TV')->checkBox(array('value'=>'Watching TV')) ?> 
                </div>

                <div class="chk-box">
                    <?= $form->field($model,'playing_computer_games')->checkBox(array('value'=>'Playing Computer Games')) ?> 
                </div>

                <div class="chk-box">
                <?= $form->field($model,'swiming')->checkBox(array('value'=>'Swiming')) ?> 
                </div>

               <div class="form-group">
                    <?= Html::submitButton('Register', ['class' => 'btn btn-primary', 'name' => 'registration-button']) ?>
                </div>

            <?php ActiveForm::end(); ?>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="table-responsive">
                <table class="table">
                    <tr>
                        <th>SR</th>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>DOB</th>
                        <th>Gender</th>
                        <th>Hobbie</th>
                        <th>Age</th>
                    </tr>
                    <?php 
                        $count = 1;
                        foreach ($persons as $value) { ?>
                            <tr>
                                <td><?= $count?></td>
                                <td><?= $value['id'] ?></td>
                                <td><?= $value['name'] ?></td>
                                <td><?= $value['email'] ?></td>
                                <td><?= $value['mobile'] ?></td>
                                <td><?= $value['dob'] ?></td>
                                <td><?= $value['gender'] ?></td>
                                <td>
                                    <?php 
                                        $result = '';
                                        $h1 = $value['playing_cricket'];
                                        $h2 = $value['watching_TV'];
                                        $h3 = $value['playing_computer_games'];
                                        $h4 = $value['swiming'];

                                        $x = array_diff(array($h1,$h2,$h3,$h4), array('0'));
                                        echo implode(', ', $x);
                                    ?>
                                <td> 
                                <?php 
                                    $date1 = date('d-m-Y');
                                    $date2 = $value['dob'];
                                    $diff = abs(strtotime($date2) - strtotime($date1));
                                    echo $years = floor($diff / (365*60*60*24));
                                ?>
                                </td>
                            </tr>

                        <?php $count++;
                        }
                    ?>    
                </table>
            </div>
        </div>
    </div>
</div>
